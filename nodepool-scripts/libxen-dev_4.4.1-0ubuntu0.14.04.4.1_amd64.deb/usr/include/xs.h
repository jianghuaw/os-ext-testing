#warning xs.h is deprecated use xenstore.h instead
#include <xenstore.h>
